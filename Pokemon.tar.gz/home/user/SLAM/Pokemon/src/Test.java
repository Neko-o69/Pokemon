public class Test {

    public static void main(String[] args) {

        Type feu = new Type(1, "Feu");
        Type eau = new Type(2, "Eau");

        PokemonEspece salamèche = new PokemonEspece(1, "Salameche", feu);
        PokemonEspece carapuce = new PokemonEspece(2, "Carapuce", eau);

        PokemonInstance p1 = new PokemonInstance(salamèche, 10);
        PokemonInstance p2 = new PokemonInstance(carapuce, 10);

        Attaque flamme = new Attaque("Flamme", 20, feu);

        while (!p1.estKO() && !p2.estKO()) {
            Combat.attaquer(p1, p2, flamme);

            if (!p2.estKO()) {
                Combat.attaquer(p2, p1, flamme);
            }
        }

        if (p1.estKO()) {
            System.out.println("Carapuce gagne !");
        } else {
            System.out.println("Salameche gagne !");
        }
    }
}