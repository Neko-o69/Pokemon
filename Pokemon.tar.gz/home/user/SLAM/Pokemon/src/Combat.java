import java.util.Random;

public class Combat {

    public static void attaquer(PokemonInstance attaquant, PokemonInstance defenseur, Attaque attaque) {
        int degats = calculDegats(attaque, attaquant, defenseur);

        System.out.println(attaquant.getNom() + " utilise " + attaque.getNom());
        System.out.println("Dégâts infligés : " + degats);

        defenseur.subirDegats(degats);

        System.out.println(defenseur.getNom() + " PV restants : " + defenseur.getPv());
    }

    public static int calculDegats(Attaque attaque, PokemonInstance attaquant, PokemonInstance defenseur) {
        int base = attaque.getPuissance();

        double multiplicateur = getEfficacite(attaque.getType(), defenseur.getType());

        return (int)(base * multiplicateur);
    }

    public static double getEfficacite(Type attaque, Type defense) {
        // simplifié (tu peux améliorer avec la BDD)
        if (attaque.getNom().equals("Feu") && defense.getNom().equals("Plante")) {
            System.out.println("C'est super efficace !");
            return 2.0;
        }
        if (attaque.getNom().equals("Eau") && defense.getNom().equals("Feu")) {
            return 2.0;
        }
        return 1.0;
    }
}