public class Pokemon {

    private String nom;
    private int pvMax;
    private int pv;
    private int attaque;
    private int defense;
    private int vitesse;
    private Type type1;
    private Type type2;
    private Attaque[] attaques = new Attaque[4];
    private Etat etat;

    public Pokemon(String nom) {
        this.nom = nom;
    }

    public Attaque getAttaqueByIndex(int index) {
        return attaques[index];
    }

    public int attaquer(Attaque attaque, Pokemon adversaire) {
        // logique d'attaque à implémenter
        return 0;
    }
    
}
